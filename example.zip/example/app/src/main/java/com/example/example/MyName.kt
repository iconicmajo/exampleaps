package com.example.example

data class MyName(var name: String= "", var nickname: String="")